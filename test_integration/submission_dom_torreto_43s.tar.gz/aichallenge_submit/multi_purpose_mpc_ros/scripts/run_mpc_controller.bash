#!/bin/bash
# shellcheck disable=SC1091
source "$(ros2 pkg prefix multi_purpose_mpc_ros)/.venv/bin/activate"
exec python3 "$(ros2 pkg prefix multi_purpose_mpc_ros)/lib/multi_purpose_mpc_ros/mpc_controller" "$@"
